package kz.test.lab2.fragment

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import kz.test.lab2.R
import kz.test.lab2.adapter.PersonListAdapter
import kz.test.lab2.databinding.FragmentPersonListBinding
import kz.test.lab2.model.entity.Person
import kz.test.lab2.model.network.ApiClient
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class PersonListFragment : Fragment() {

    companion object {
        fun newInstance() = PersonListFragment()
    }

    private var _binding: FragmentPersonListBinding? = null
    private val binding
        get() = _binding!!

    private val adapter: PersonListAdapter by lazy {
        PersonListAdapter()
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentPersonListBinding.inflate(layoutInflater, container, false)
        return _binding?.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        setupUI()

//        ApiClient.getPersonList().enqueue(object : Callback<List<Person>> {
//            override fun onResponse(
//                call: Call<List<Person>>,
//                response: Response<List<Person>>
//            ) {
//                if (response.isSuccessful) {
//                    val body = response.body()
//                    if (body != null) {
//                        adapter.setItems(body)
//                    }
//                }
//            }
//
//            override fun onFailure(p0: Call<List<Person>>, p1: Throwable) {
//                println(p0)
//            }
//        })
    }

    private fun setupUI() {
        with(binding) {
            personList.adapter = adapter
        }
    }
}