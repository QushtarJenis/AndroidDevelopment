package kz.test.lab2.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import kz.test.lab2.R
import kz.test.lab2.databinding.ItemPersonBinding
import kz.test.lab2.model.entity.Person
import kz.test.lab2.util.PersonDiffUtilCallback

class PersonListAdapter : RecyclerView.Adapter<PersonListAdapter.ViewHolder>() {

    private val items: ArrayList<Person> = arrayListOf()

    fun getCurrentList(): ArrayList<Person> {
        return items
    }

    fun setItems(offerList: List<Person>) {
        val diffCallback = PersonDiffUtilCallback(items, offerList)
        val diffResult: DiffUtil.DiffResult = DiffUtil.calculateDiff(diffCallback)

        items.clear()
        items.addAll(offerList)

        diffResult.dispatchUpdatesTo(this)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(
            ItemPersonBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        )
    }

    override fun getItemCount(): Int {
        return items.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(items[position])
    }

    inner class ViewHolder(
        private val binding: ItemPersonBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        private val context = binding.root.context

        fun bind(person: Person) {
            val info = person.info

            val image: ImageView = binding.root.findViewById(R.id.airline_image)

            with(binding) {
                departureTime.text = flight.departureTimeInfo
                arrivalTime.text = flight.arrivalTimeInfo
                route.text = context.getString(
                    R.string.route_fmt,
                    flight.departureLocation.code,
                    flight.arrivalLocation.code
                )
                duration.text = context.getString(
                    R.string.time_fmt,
                    getTimeFormat(flight.duration).first.toString(),
                    getTimeFormat(flight.duration).second.toString()
                )
                direct.text = context.getString(R.string.direct)
                price.text = context.getString(R.string.price_fmt, offer.price.toString())
            }
        }

        private fun getTimeFormat(minutes: Int): Pair<Int, Int> = Pair(
            first = minutes / 60,
            second = minutes % 60
        )

    }
}