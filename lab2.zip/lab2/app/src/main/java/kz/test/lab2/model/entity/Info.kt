package kz.test.lab2.model.entity

import com.google.gson.annotations.SerializedName

data class Info(
    val awards: String?,
    val born: String?,
    @SerializedName("cause_of_death")
    val causeOfDeath: String?,
    val children: List<String>?,
    val conflicts: List<String>?,
    val died: String?,
    @SerializedName("notable_work")
    val notableWork: List<String>?,
    val occupation: List<String>?,
    val office: List<String>?,
    val parents: List<String>?,
    val partners: String?,
    @SerializedName("resting_place")
    val restingPlace: String?,
    val spouses: String?,
    val years: String?
)