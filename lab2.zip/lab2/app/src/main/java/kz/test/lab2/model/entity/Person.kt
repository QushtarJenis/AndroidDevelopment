package kz.test.lab2.model.entity

data class Person(
    val info: Info?,
    val name: String,
    val title: String
)

